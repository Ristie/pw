﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class zad2 : MonoBehaviour
{
    public int x = 3;
    // Start is called before the first frame update
    void Start()
    {
        for (int i = 0; i < x; i++){
            print("Emilia");
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
