﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
namespace BMi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text != "") && (textBox2.Text != ""))
            {
                if (men.Checked == true)
                {
                    wynik.ForeColor = Color.Black;
                    double wzrost = Convert.ToDouble(textBox1.Text);
                    double waga = Convert.ToDouble(textBox2.Text);
                    Int32 wiek = Convert.ToInt32(textBox3.Text);
                    //Debug.WriteLine(wzrost);
                   
                    double bmi = 9.99 * waga + 6.25 * wzrost - 4.92 * wiek + 5;
                    wynik.Text = bmi.ToString();
                }
              else  if (women.Checked == true)
                {
                    wynik.ForeColor = Color.Black;
                    double wzrost = Convert.ToDouble(textBox1.Text);
                    double waga = Convert.ToDouble(textBox2.Text);
                    Int32 wiek = Convert.ToInt32(textBox3.Text);
                    //Debug.WriteLine(wzrost);
                    double bmi = 9.99 * waga + 6.25 * wzrost - 4.92 * wiek  -161;
                    wynik.Text = bmi.ToString();
                }
                else
                {
                    wynik.ForeColor = Color.Red;
                    wynik.Text = "Podaj płeć";
                }
            }
            else
            {
                wynik.ForeColor = Color.Red;
                wynik.Text = "Brak danych";
            }
        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
            women.Checked = false;
            men.Checked = false;
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }
    }
}
