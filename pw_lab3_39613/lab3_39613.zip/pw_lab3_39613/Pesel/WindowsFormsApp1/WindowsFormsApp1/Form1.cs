﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String P = textBox1.Text;
            int d = P.Length;
            // Debug.WriteLine(d);
            // Debug.WriteLine(P[3]);
            if (d == 11)
            {

                // int suma = P[0];
                int suma = 1 * P[0] + 3 * P[1] + 7 * P[2] + 9 * P[3] + 1 * P[4] + 3 * P[5] + 7 * P[6] + 9 * P[7] + 1 * P[8] + 3 * P[9]-44*48;//przesuniecie
                // Int32 suma = 1 * Convert.ToInt32(P[0]) + 3 * Convert.ToInt32(P[1]) + 7 * Convert.ToInt32(P[2]) + 9 * Convert.ToInt32(P[3]) + 1 * Convert.ToInt32(P[4]) + 3 * Convert.ToInt32(P[5]) + 7 * Convert.ToInt32(P[6]) + 9 * Convert.ToInt32(P[7]) + 1 * Convert.ToInt32(P[8]) + 3 * Convert.ToInt32(P[9]);
                Int32 mod = suma % 10;
                Int32 lastvalue = P[10]-48;
                if (10-mod == lastvalue)
                {
                    wynik.Text = "PESEL poprawny.";
                }
                else
                {
                 wynik.Text = "PESEL niepoprawny.";
                }
            }
            else wynik.Text = "Niepoprawna wartość!";
        }
    }
}
