﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class s1 : MonoBehaviour
{
    GameObject[] szukanekule;
    // Start is called before the first frame update
    void Start()
    {
        szukanekule = GameObject.FindGameObjectsWithTag("kula");
        foreach(GameObject k in szukanekule)
        {
            Destroy(k);
        }
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
