﻿namespace WindowsFormsApp3
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.marka1 = new System.Windows.Forms.TextBox();
            this.model1 = new System.Windows.Forms.TextBox();
            this.pojemnosc1 = new System.Windows.Forms.TextBox();
            this.kolor1 = new System.Windows.Forms.TextBox();
            this.cena1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.id1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // marka1
            // 
            this.marka1.Location = new System.Drawing.Point(435, 67);
            this.marka1.Name = "marka1";
            this.marka1.Size = new System.Drawing.Size(100, 20);
            this.marka1.TabIndex = 0;
            // 
            // model1
            // 
            this.model1.Location = new System.Drawing.Point(435, 109);
            this.model1.Name = "model1";
            this.model1.Size = new System.Drawing.Size(100, 20);
            this.model1.TabIndex = 1;
            // 
            // pojemnosc1
            // 
            this.pojemnosc1.Location = new System.Drawing.Point(435, 156);
            this.pojemnosc1.Name = "pojemnosc1";
            this.pojemnosc1.Size = new System.Drawing.Size(100, 20);
            this.pojemnosc1.TabIndex = 2;
            // 
            // kolor1
            // 
            this.kolor1.Location = new System.Drawing.Point(435, 203);
            this.kolor1.Name = "kolor1";
            this.kolor1.Size = new System.Drawing.Size(100, 20);
            this.kolor1.TabIndex = 3;
            // 
            // cena1
            // 
            this.cena1.Location = new System.Drawing.Point(435, 255);
            this.cena1.Name = "cena1";
            this.cena1.Size = new System.Drawing.Size(100, 20);
            this.cena1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(319, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "marka";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(319, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "model";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(319, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "pojemnosc";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(319, 203);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "kolor";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(319, 255);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "cena";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(280, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(119, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Podaj dane samochodu";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(655, 224);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 11;
            this.button1.Text = "Dodaj";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // id1
            // 
            this.id1.Location = new System.Drawing.Point(435, 296);
            this.id1.Name = "id1";
            this.id1.Size = new System.Drawing.Size(100, 20);
            this.id1.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(319, 296);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(15, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "id";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.id1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cena1);
            this.Controls.Add(this.kolor1);
            this.Controls.Add(this.pojemnosc1);
            this.Controls.Add(this.model1);
            this.Controls.Add(this.marka1);
            this.Name = "Form2";
            this.Text = "Dodaj";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox marka1;
        private System.Windows.Forms.TextBox model1;
        private System.Windows.Forms.TextBox pojemnosc1;
        private System.Windows.Forms.TextBox kolor1;
        private System.Windows.Forms.TextBox cena1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox id1;
        private System.Windows.Forms.Label label7;
    }
}