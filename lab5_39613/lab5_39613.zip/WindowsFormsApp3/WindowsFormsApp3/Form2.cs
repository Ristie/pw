﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace WindowsFormsApp3
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        public  MySqlDataAdapter CreateCustomerAdapter(MySqlConnection conn)
        {
            string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=komis;";

            MySqlConnection databaseConnection = new MySqlConnection(connectionString);
            MySqlDataAdapter da = new MySqlDataAdapter();
            MySqlParameter parm;
          
            MySqlCommand commandDatabase = new MySqlCommand("UPDATE komis SET id=@id, marka=@marka, model=@model, pojemnosc=@pojemnosc, kolor=@kolor, cena=@cena WHERE id=@oldId", databaseConnection);
            commandDatabase.Parameters.Add("@id", MySqlDbType.VarChar, 15);
            commandDatabase.Parameters.Add("@marka", MySqlDbType.VarChar, 15);
            commandDatabase.Parameters.Add("@model", MySqlDbType.VarChar, 15);
            commandDatabase.Parameters.Add("@pojemnosc", MySqlDbType.VarChar, 15);
            commandDatabase.Parameters.Add("@kolor", MySqlDbType.VarChar, 15);
            commandDatabase.Parameters.Add("@cena", MySqlDbType.VarChar, 15);

            // Create the UpdateCommand.
            commandDatabase = new MySqlCommand("UPDATE mytable SET id=@id, name=@name WHERE id=@oldId", conn);
            commandDatabase.Parameters.Add("@id", MySqlDbType.VarChar, 15, "id");
          commandDatabase.Parameters.Add("@marka", MySqlDbType.VarChar, 15, marka1.Text);
            commandDatabase.Parameters.Add("@model", MySqlDbType.VarChar, 15, model1.Text);
            commandDatabase.Parameters.Add("@pojemnosc", MySqlDbType.VarChar, 15, pojemnosc1.Text);
            commandDatabase.Parameters.Add("@kolor", MySqlDbType.VarChar, 15, kolor1.Text);
            commandDatabase.Parameters.Add("@cena", MySqlDbType.VarChar, 15, cena1.Text);

            parm = commandDatabase.Parameters.Add("@oldId", MySqlDbType.VarChar, 15, "id");
            parm.SourceVersion = DataRowVersion.Original;

            da.UpdateCommand = commandDatabase;

            return da;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=komis;";
           
            MySqlConnection databaseConnection = new MySqlConnection(connectionString);
            
           string insertQuery = "INSERT INTO komis.samochody(marka,model,pojemnosc,kolor,cena,id) VALUES('" + marka1.Text + "','" + model1.Text + "'," + pojemnosc1.Text + ",'" + kolor1.Text + "'," + cena1.Text + ","+id1.Text+ ")";
            databaseConnection.Open();
            MySqlCommand command = new MySqlCommand(insertQuery, databaseConnection);
            try
            {
                if (command.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Dane wysłane do tabeli");
                }
                else
                {
                    MessageBox.Show("Data nie zostały wysłane");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

           databaseConnection.Close();
        
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
