﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class kulki : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject[] kulka;
    void Start()
    {
        InvokeRepeating("GenerujKulki", 3f, 3f);
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.KeypadEnter)|| Input.GetKey(KeyCode.Return))
        {
            CancelInvoke("GenerujKulki");
            print("Zatrzymano generowanie obiektów");
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            GenerujKulki();
            print("Wygenerowano losowy obiekt");
        }
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            Instantiate(kulka[0], transform.position, Quaternion.identity);
            print("Wygenerowano obiekt 1");
        }
        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            Instantiate(kulka[1], transform.position, Quaternion.identity);
            print("Wygenerowano obiekt 2 ");
        }
        if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            Instantiate(kulka[2], transform.position, Quaternion.identity);
            print("Wygenerowano obiekt 3 ");
        }
        if (Input.GetKeyDown(KeyCode.Alpha4))
        {
            Instantiate(kulka[3], transform.position, Quaternion.identity);
            print("Wygenerowano obiekt 4 ");
        }
        if (Input.GetKeyDown(KeyCode.Alpha5))
        {
            Instantiate(kulka[4], transform.position, Quaternion.identity);
            print("Wygenerowano obiekt 5 ");
        }
    }
    void GenerujKulki()
    {
        int los = Random.Range(0, kulka.Length);
        Instantiate(kulka[los], transform.position, Quaternion.identity);
    }
}
