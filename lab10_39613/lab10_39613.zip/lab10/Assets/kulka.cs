﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class kulka : MonoBehaviour
{
    // Start is called before the first frame update
    public float speed;
    public GameObject[] obiekt;
  
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        float x = Input.GetAxis("Horizontal");
     //   print(x);
        float y = Input.GetAxis("Vertical");
    //    print(y);
        transform.Translate(x*Time.deltaTime* speed, y * Time.deltaTime* speed, 0);
        if (Input.GetMouseButton(0))
        {
            int los = Random.Range(0, obiekt.Length);
            
            Vector3 pozycja = Input.mousePosition;
            pozycja.z = 15f;
            pozycja = Camera.main.ScreenToWorldPoint(pozycja);
            Instantiate(obiekt[los], pozycja, Quaternion.identity);
        }

    }
}
