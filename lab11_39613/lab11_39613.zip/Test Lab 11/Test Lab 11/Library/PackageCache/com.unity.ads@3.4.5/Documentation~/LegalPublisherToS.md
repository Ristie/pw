<script type="text/javascript">

window.location = "https://unity3d.com/legal/ads-publishers-terms-of-service"

</script>
