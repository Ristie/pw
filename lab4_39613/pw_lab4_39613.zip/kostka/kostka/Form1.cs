﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace kostka
{
    public partial class Form1 : Form
    {
        Random rnd = new Random();
        int value;
       
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label3.ForeColor = Color.Blue;
        }

       
        private void key_r(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'r')
            {

                value = rnd.Next(1, 7);
                label3.Text = value.ToString();
            }
        }

        private void label3_Click(object sender, MouseEventArgs e)
        {
            if(e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                Clipboard.SetText(label3.Text);
            }
        }

    }
}
